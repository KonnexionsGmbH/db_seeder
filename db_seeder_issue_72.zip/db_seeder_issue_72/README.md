### System Requirements

- Docker, e.g Docker Desktop for windows
- Gradle Build Tool
- Java 14 JDK
- Operating system: any Java-enabled Linux or Windows variant

### Compiling

- `gradle copyJarToLib`

### Running

- `run_i72` or `./run_i72.sh`
